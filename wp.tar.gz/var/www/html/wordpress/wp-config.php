<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', '3993' );

/** MySQL hostname */
define( 'DB_HOST', '10.44.0.27' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ZKV8!q.r5:APu Yq<wY9-)_^uMP9Ya~7}<z@?nz^:}LPJb%Pax}3XfX%^u3X?>E|' );
define( 'SECURE_AUTH_KEY',  'QnyD[O@J*xyG2Rc`hvueAMx}HQ3W19)6}?gSui%9PE7d3!zH-Goi{lU`sJcICu/`' );
define( 'LOGGED_IN_KEY',    '%-)66![)vg+Ei+KTMo:,Hm*:>4B8zt( 97! AqN u;*LdV4:Gmw0WX.xSC2ClQB*' );
define( 'NONCE_KEY',        'Zvqn6hX?Z}7nLff%>n6[!n1`jfPOxC9#{]h`gr<o-&x.W+lOcdC&v9#x*~QY$)=d' );
define( 'AUTH_SALT',        'U73AD6{P:y&FMI&n|q>Vh^LTw)+`qB8^O8fGQ(7]/RE@h= Ad6ph_IpJuK*b(3K!' );
define( 'SECURE_AUTH_SALT', 'v1jl|$^or#rBLsy?i:M9nJ@vD@Rbik+5v80X)bvDSOM@@Y*JFk#:YascYDB,qtm|' );
define( 'LOGGED_IN_SALT',   '<[zPnYeh`n8}v%xLNl>4F_*|K;%3Me!Es7>~6lWrLeZ7EFTq2935|XntuH?+q>vA' );
define( 'NONCE_SALT',       'n4:evI<A&qHPnJ&{h$Z{gnV,;bC#yBWvti~&RQh!UPo#GAI#GI,N$wWvC=5csBHT' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
